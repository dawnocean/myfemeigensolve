#pragma once

#ifdef EIGENSOLVE_USE_SLEPC

#include "eigensolver.hpp"
#include <slepceps.h>

namespace eigensolve {

/// SLEPc-based eigensolver for the waveguide block eigenvalue problem.
///
/// Forms the full block system:
///   LHS = [A, C; 0, D],  RHS = [M, 0; C^T, 0]
/// and solves  LHS * x = beta^2 * RHS * x  using SLEPc's EPS
/// with Krylov-Schur + shift-and-invert spectral transformation.
class SlepcBlockEigensolver : public EigensolverBase {
public:
    SlepcBlockEigensolver(MPI_Comm comm);
    ~SlepcBlockEigensolver() override;

    void SetNumModes(int n) override { num_modes_ = n; }
    void SetShift(double sigma) override { sigma_ = sigma; }
    void SetTolerance(double tol) override { tol_ = tol; }
    void SetMaxIterations(int max_it) override { max_iter_ = max_it; }
    void SetVerbose(int v) override { verbose_ = v; }

    void Solve(mfem::HypreParMatrix &A, mfem::HypreParMatrix &M,
               mfem::HypreParMatrix &C, mfem::HypreParMatrix &Ct,
               mfem::HypreParMatrix &D) override;

    const std::vector<double>& Eigenvalues() const override { return eigenvalues_; }
    const std::vector<mfem::HypreParVector*>& Eigenvectors() const override {
        return eigenvectors_;
    }

private:
    MPI_Comm comm_;
    int num_modes_ = 6;
    double sigma_ = 0.0;
    double tol_ = 1e-6;
    int max_iter_ = 200;
    int verbose_ = 1;

    std::vector<double> eigenvalues_;
    std::vector<mfem::HypreParVector*> eigenvectors_;

    /// Build a flat PETSc MPIAIJ matrix from a 2x2 block of HYPRE matrices.
    /// Null entries are treated as zero blocks.
    static Mat FormPetscBlockMatrix(MPI_Comm comm,
                                    mfem::HypreParMatrix *blocks[2][2],
                                    HYPRE_BigInt nt_global, HYPRE_BigInt nz_global,
                                    int local_nt, int local_nz);

    /// Insert one HYPRE sub-matrix into a PETSc matrix with global row/col offsets.
    static void InsertHypreBlock(Mat P, mfem::HypreParMatrix &H,
                                 PetscInt row_offset, PetscInt col_offset);
};

} // namespace eigensolve

#endif // EIGENSOLVE_USE_SLEPC
