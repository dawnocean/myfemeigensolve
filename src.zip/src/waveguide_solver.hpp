#pragma once
#include "mfem.hpp"
#include "eigensolver.hpp"
#include "mesh_generator.hpp"
#include <nlohmann/json.hpp>
#include <vector>

namespace eigensolve {

struct ModeResult {
    int mode_number;
    double beta_squared;
    double beta;
    double neff;
};

/// PML stretching function: s(d) = 1 + sigma_max * (d/d_pml)^p
/// where d = distance into PML, d_pml = PML thickness.
/// This is real-valued coordinate stretching for real eigenvalue formulations.
class PMLStretchingFunction {
public:
    PMLStretchingFunction(const MeshInfo &info, double sigma_max = 5.0, int p = 2)
        : info_(info), sigma_max_(sigma_max), p_(p) {}

    /// Compute s_x(x) - stretching in x direction
    double sx(double x, double /*y*/) const {
        // xmin side PML
        if (info_.pml_thickness[3] > 0 && x < info_.phys_xmin) {
            double d = info_.phys_xmin - x;
            double t = d / info_.pml_thickness[3];
            return 1.0 + sigma_max_ * std::pow(t, p_);
        }
        // xmax side PML
        if (info_.pml_thickness[1] > 0 && x > info_.phys_xmax) {
            double d = x - info_.phys_xmax;
            double t = d / info_.pml_thickness[1];
            return 1.0 + sigma_max_ * std::pow(t, p_);
        }
        return 1.0;
    }

    /// Compute s_y(y) - stretching in y direction
    double sy(double /*x*/, double y) const {
        // ymin side PML
        if (info_.pml_thickness[0] > 0 && y < info_.phys_ymin) {
            double d = info_.phys_ymin - y;
            double t = d / info_.pml_thickness[0];
            return 1.0 + sigma_max_ * std::pow(t, p_);
        }
        // ymax side PML
        if (info_.pml_thickness[2] > 0 && y > info_.phys_ymax) {
            double d = y - info_.phys_ymax;
            double t = d / info_.pml_thickness[2];
            return 1.0 + sigma_max_ * std::pow(t, p_);
        }
        return 1.0;
    }

private:
    const MeshInfo &info_;
    double sigma_max_;
    int p_;
};

/// Scalar coefficient: det(J_pml) = s_x * s_y
/// Used for curl-curl integrator scaling.
class PMLDetCoefficient : public mfem::Coefficient {
public:
    PMLDetCoefficient(const PMLStretchingFunction &pml) : pml_(pml) {}
    double Eval(mfem::ElementTransformation &T,
                const mfem::IntegrationPoint &ip) override {
        double x[3];
        mfem::Vector transip(x, 3);
        T.Transform(ip, transip);
        return pml_.sx(x[0], x[1]) * pml_.sy(x[0], x[1]);
    }
private:
    const PMLStretchingFunction &pml_;
};

/// 2x2 diagonal matrix coefficient: diag(s_y/s_x, s_x/s_y)
/// Used for VectorFEMassIntegrator in PML regions.
class PMLTensorCoefficient : public mfem::MatrixCoefficient {
public:
    PMLTensorCoefficient(const PMLStretchingFunction &pml)
        : mfem::MatrixCoefficient(2), pml_(pml) {}
    void Eval(mfem::DenseMatrix &M, mfem::ElementTransformation &T,
              const mfem::IntegrationPoint &ip) override {
        double x[3];
        mfem::Vector transip(x, 3);
        T.Transform(ip, transip);
        double sx = pml_.sx(x[0], x[1]);
        double sy = pml_.sy(x[0], x[1]);
        M.SetSize(2, 2);
        M = 0.0;
        M(0, 0) = sy / sx;
        M(1, 1) = sx / sy;
    }
private:
    const PMLStretchingFunction &pml_;
};

/// Inverse PML tensor: diag(s_x/s_y, s_y/s_x)
/// Used for diffusion integrator on H1 space in PML.
class PMLInvTensorCoefficient : public mfem::MatrixCoefficient {
public:
    PMLInvTensorCoefficient(const PMLStretchingFunction &pml)
        : mfem::MatrixCoefficient(2), pml_(pml) {}
    void Eval(mfem::DenseMatrix &M, mfem::ElementTransformation &T,
              const mfem::IntegrationPoint &ip) override {
        double x[3];
        mfem::Vector transip(x, 3);
        T.Transform(ip, transip);
        double sx = pml_.sx(x[0], x[1]);
        double sy = pml_.sy(x[0], x[1]);
        M.SetSize(2, 2);
        M = 0.0;
        M(0, 0) = sx / sy;
        M(1, 1) = sy / sx;
    }
private:
    const PMLStretchingFunction &pml_;
};

/// Scalar PML coefficient for scalar mass: s_x * s_y * f(x)
/// where f(x) is an underlying scalar coefficient (e.g., epsilon).
class PMLScalarCoefficient : public mfem::Coefficient {
public:
    PMLScalarCoefficient(const PMLStretchingFunction &pml, mfem::Coefficient &base)
        : pml_(pml), base_(base) {}
    double Eval(mfem::ElementTransformation &T,
                const mfem::IntegrationPoint &ip) override {
        double x[3];
        mfem::Vector transip(x, 3);
        T.Transform(ip, transip);
        double det = pml_.sx(x[0], x[1]) * pml_.sy(x[0], x[1]);
        return det * base_.Eval(T, ip);
    }
private:
    const PMLStretchingFunction &pml_;
    mfem::Coefficient &base_;
};

/// Product of a MatrixCoefficient and a scalar Coefficient: M(x) * f(x)
class ScaledMatrixCoefficient : public mfem::MatrixCoefficient {
public:
    ScaledMatrixCoefficient(mfem::MatrixCoefficient &mat, mfem::Coefficient &scalar)
        : mfem::MatrixCoefficient(mat.GetHeight()), mat_(mat), scalar_(scalar) {}
    void Eval(mfem::DenseMatrix &M, mfem::ElementTransformation &T,
              const mfem::IntegrationPoint &ip) override {
        mat_.Eval(M, T, ip);
        double s = scalar_.Eval(T, ip);
        M *= s;
    }
private:
    mfem::MatrixCoefficient &mat_;
    mfem::Coefficient &scalar_;
};

class WaveguideSolver {
public:
    WaveguideSolver(mfem::ParMesh &pmesh, const nlohmann::json &config,
                    const MeshInfo &mesh_info);
    ~WaveguideSolver();

    std::vector<ModeResult> Solve();
    void SaveModeField(int mode_idx, const std::string &output_dir);
    void SaveAllModeFields(const std::string &output_dir);

    /// Export mode field sampled on a uniform grid to a .dat file for PNG plotting.
    void ExportModeFieldGrid(int mode_idx, const std::string &output_dir,
                             const ModeResult &mode_info, int nx = 256, int ny = 256);
    /// Export all mode fields and generate PNG via Python script.
    void ExportAllModeFieldsPNG(const std::string &output_dir,
                                const std::vector<ModeResult> &modes);

private:
    mfem::ParMesh &pmesh_;
    const nlohmann::json &config_;
    MeshInfo mesh_info_;

    mfem::ND_FECollection *nd_fec_ = nullptr;
    mfem::ParFiniteElementSpace *nd_fespace_ = nullptr;
    mfem::H1_FECollection *h1_fec_ = nullptr;
    mfem::ParFiniteElementSpace *h1_fespace_ = nullptr;

    mfem::HypreParMatrix *K_ = nullptr;
    mfem::HypreParMatrix *M_eps_ = nullptr;
    mfem::HypreParMatrix *M_ = nullptr;
    mfem::HypreParMatrix *A_ = nullptr;
    mfem::HypreParMatrix *S_zz_ = nullptr;
    mfem::HypreParMatrix *M_eps_zz_ = nullptr;
    mfem::HypreParMatrix *D_ = nullptr;
    mfem::HypreParMatrix *C_ = nullptr;
    mfem::HypreParMatrix *Ct_ = nullptr;

    EigensolverBase *eigensolver_ = nullptr;

    double wavelength_, k0_, n_core_, n_clad_;
    bool has_pml_ = false;

    void AssembleMatrices();
};

} // namespace eigensolve
