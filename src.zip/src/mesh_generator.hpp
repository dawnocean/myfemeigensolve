#pragma once
#include "mfem.hpp"
#include <nlohmann/json.hpp>

namespace eigensolve {

/// Information about the generated mesh, including PML region boundaries.
struct MeshInfo {
    /// Physical domain half-extents (before PML extension)
    double phys_xmin, phys_xmax, phys_ymin, phys_ymax;
    /// Total domain half-extents (including PML)
    double total_xmin, total_xmax, total_ymin, total_ymax;
    /// PML thickness on each side (0 if no PML)
    double pml_thickness[4]; // [ymin, xmax, ymax, xmin] matching bdr attr order
};

/// Generate a 2D waveguide cross-section mesh with material attributes.
/// Core elements get attribute 1, cladding elements get attribute 2,
/// PML elements get attribute 3.
/// The mesh is centered at the origin.
/// Boundary attributes: ymin=1, xmax=2, ymax=3, xmin=4 (MakeCartesian2D convention).
mfem::Mesh* GenerateWaveguideMesh(const nlohmann::json &config, MeshInfo &info);

} // namespace eigensolve
