#include "eigensolver.hpp"
#include <cmath>
#include <algorithm>
#include <numeric>
#include <iostream>
#include <iomanip>

namespace eigensolve {

using namespace mfem;

BlockEigensolver::BlockEigensolver(MPI_Comm comm) : comm_(comm) {}

BlockEigensolver::~BlockEigensolver()
{
    for (auto *v : result_.eigenvectors) delete v;
}

void BlockEigensolver::MOrthogonalize(
    std::vector<HypreParVector*> &vecs, HypreParMatrix &M)
{
    int k = vecs.size();
    HypreParVector Mv(M.GetComm(), M.GetGlobalNumRows(), M.GetRowStarts());

    for (int i = 0; i < k; i++) {
        for (int pass = 0; pass < 2; pass++) {
            for (int j = 0; j < i; j++) {
                M.Mult(*vecs[i], Mv);
                double dot = InnerProduct(comm_, *vecs[j], Mv);
                vecs[i]->Add(-dot, *vecs[j]);
            }
        }
        M.Mult(*vecs[i], Mv);
        double norm_sq = InnerProduct(comm_, *vecs[i], Mv);
        if (norm_sq > 1e-28) {
            *vecs[i] /= std::sqrt(norm_sq);
        }
    }
}

// Helper: compute B_eff * x = M*x - C * D^{-1} * C^T * x
static void ApplyBeff(
    HypreParMatrix &M, HypreParMatrix &C, HypreParMatrix &Ct,
    SuperLUSolver &D_solver,
    const HypreParVector &x, HypreParVector &Bx,
    HypreParVector &tmp_z1, HypreParVector &tmp_z2, HypreParVector &tmp_t)
{
    M.Mult(x, Bx);
    Ct.Mult(x, tmp_z1);
    D_solver.Mult(tmp_z1, tmp_z2);
    C.Mult(tmp_z2, tmp_t);
    Bx.Add(-1.0, tmp_t);
}

void BlockEigensolver::Solve(
    HypreParMatrix &A, HypreParMatrix &M,
    HypreParMatrix &C, HypreParMatrix &Ct,
    HypreParMatrix &D)
{
    int myid;
    MPI_Comm_rank(comm_, &myid);

    HYPRE_BigInt n_t = A.GetGlobalNumRows();
    HYPRE_BigInt n_z = D.GetGlobalNumRows();
    int nev = num_modes_;
    int block_size = std::min(3 * nev + 4, (int)n_t);

    if (myid == 0 && verbose_ > 0) {
        std::cout << "\n=== Block Shift-and-Invert Eigensolver ===" << std::endl;
        std::cout << "  ND DOFs (E_t): " << n_t << std::endl;
        std::cout << "  H1 DOFs (E_z): " << n_z << std::endl;
        std::cout << "  Total block DOFs: " << n_t + n_z << std::endl;
        std::cout << "  Modes requested: " << nev << std::endl;
        std::cout << "  Shift (sigma): " << sigma_ << std::endl;
        std::cout << "  Block size: " << block_size << std::endl;
    }

    // ── Form block shifted matrix S = [A-σM, C; -σCᵀ, D] ──────────────────
    HypreParMatrix *A_shifted = Add(1.0, A, -sigma_, M);
    HypreParMatrix *Ct_scaled = new HypreParMatrix(Ct);
    *Ct_scaled *= -sigma_;

    Array2D<const HypreParMatrix*> blocks(2, 2);
    blocks(0, 0) = A_shifted;
    blocks(0, 1) = &C;
    blocks(1, 0) = Ct_scaled;
    blocks(1, 1) = &D;
    HypreParMatrix *S_block = HypreParMatrixFromBlocks(blocks);

    if (myid == 0 && verbose_ > 0) {
        std::cout << "  Block matrix: " << S_block->GetGlobalNumRows()
                  << " x " << S_block->GetGlobalNumCols() << std::endl;
        std::cout << "  Factoring block system with SuperLU..." << std::flush;
    }

    SuperLURowLocMatrix S_superlu(*S_block);
    SuperLUSolver block_solver(comm_);
    block_solver.SetPrintStatistics(false);
    block_solver.SetColumnPermutation(superlu::PARMETIS);
    block_solver.SetOperator(S_superlu);

    if (myid == 0 && verbose_ > 0) {
        std::cout << " done." << std::endl;
    }

    // ── Factor D for B_eff evaluation ────────────────────────────────────────
    if (myid == 0 && verbose_ > 0) {
        std::cout << "  Factoring D matrix..." << std::flush;
    }
    SuperLURowLocMatrix D_superlu(D);
    SuperLUSolver D_solver(comm_);
    D_solver.SetPrintStatistics(false);
    D_solver.SetColumnPermutation(superlu::PARMETIS);
    D_solver.SetOperator(D_superlu);
    if (myid == 0 && verbose_ > 0) {
        std::cout << " done." << std::endl;
    }

    // ── Allocate vectors ─────────────────────────────────────────────────────
    int local_n_t = A.GetNumRows();
    int local_n_z = D.GetNumRows();

    std::vector<HypreParVector*> X(block_size), Y(block_size);
    HypreParVector block_rhs(comm_, S_block->GetGlobalNumRows(),
                             S_block->GetRowStarts());
    HypreParVector block_sol(comm_, S_block->GetGlobalNumRows(),
                             S_block->GetRowStarts());
    HypreParVector Mx(comm_, M.GetGlobalNumRows(), M.GetRowStarts());
    HypreParVector Ctx(comm_, D.GetGlobalNumRows(), D.GetRowStarts());
    HypreParVector Av(comm_, A.GetGlobalNumRows(), A.GetRowStarts());
    HypreParVector Bv(comm_, M.GetGlobalNumRows(), M.GetRowStarts());
    HypreParVector tmp_z1(comm_, D.GetGlobalNumRows(), D.GetRowStarts());
    HypreParVector tmp_z2(comm_, D.GetGlobalNumRows(), D.GetRowStarts());
    HypreParVector tmp_t(comm_, A.GetGlobalNumRows(), A.GetRowStarts());

    for (int j = 0; j < block_size; j++) {
        X[j] = new HypreParVector(comm_, A.GetGlobalNumRows(), A.GetRowStarts());
        Y[j] = new HypreParVector(comm_, A.GetGlobalNumRows(), A.GetRowStarts());
        X[j]->Randomize(42 + j);
    }
    MOrthogonalize(X, M);

    // ── Subspace iteration ───────────────────────────────────────────────────
    bool converged = false;
    double k0 = std::sqrt(sigma_) / std::sqrt(sigma_ > 0 ? sigma_ : 1.0);

    for (int iter = 0; iter < max_iter_; iter++) {
        // Apply shift-and-invert via block solve
        for (int j = 0; j < block_size; j++) {
            M.Mult(*X[j], Mx);
            Ct.Mult(*X[j], Ctx);

            double *rhs_data = block_rhs.GetData();
            for (int i = 0; i < local_n_t; i++) rhs_data[i] = Mx.GetData()[i];
            for (int i = 0; i < local_n_z; i++) rhs_data[local_n_t + i] = Ctx.GetData()[i];

            block_sol = 0.0;
            block_solver.Mult(block_rhs, block_sol);

            double *y_data = Y[j]->GetData();
            for (int i = 0; i < local_n_t; i++) y_data[i] = block_sol.GetData()[i];
        }

        MOrthogonalize(Y, M);

        // Rayleigh-Ritz with B_eff
        DenseMatrix Ar(block_size), Br(block_size);
        for (int j2 = 0; j2 < block_size; j2++) {
            A.Mult(*Y[j2], Av);
            ApplyBeff(M, C, Ct, D_solver, *Y[j2], Bv, tmp_z1, tmp_z2, tmp_t);
            for (int i = 0; i < block_size; i++) {
                Ar(i, j2) = InnerProduct(comm_, *Y[i], Av);
                Br(i, j2) = InnerProduct(comm_, *Y[i], Bv);
            }
        }

        DenseMatrix Ar_copy(Ar), Br_copy(Br);
        DenseMatrixGeneralizedEigensystem eig(Ar_copy, Br_copy, false, true);
        eig.Eval();
        Vector &eval_r = eig.EigenvaluesRealPart();
        Vector &eval_i = eig.EigenvaluesImagPart();
        DenseMatrix &evec = eig.RightEigenvectors();

        std::vector<int> idx(block_size);
        std::iota(idx.begin(), idx.end(), 0);
        std::sort(idx.begin(), idx.end(), [&](int a, int b) {
            double da = std::abs(eval_r(a) - sigma_) + 1e6 * std::abs(eval_i(a));
            double db = std::abs(eval_r(b) - sigma_) + 1e6 * std::abs(eval_i(b));
            return da < db;
        });

        for (int j2 = 0; j2 < block_size; j2++) {
            *X[j2] = 0.0;
            for (int k = 0; k < block_size; k++) {
                X[j2]->Add(evec(k, idx[j2]), *Y[k]);
            }
        }

        // Check convergence
        double max_residual = 0.0;
        for (int j2 = 0; j2 < nev; j2++) {
            double lam = eval_r(idx[j2]);
            A.Mult(*X[j2], Av);
            ApplyBeff(M, C, Ct, D_solver, *X[j2], Bv, tmp_z1, tmp_z2, tmp_t);
            Av.Add(-lam, Bv);
            double res_norm = std::sqrt(InnerProduct(comm_, Av, Av));
            double bx_norm = std::sqrt(InnerProduct(comm_, Bv, Bv));
            max_residual = std::max(max_residual,
                                    res_norm / std::max(std::abs(lam) * bx_norm, 1e-14));
        }

        if (myid == 0 && verbose_ > 0) {
            if (iter < 3 || (iter + 1) % 10 == 0 || max_residual < tol_) {
                double neff1 = eval_r(idx[0]) > 0
                    ? std::sqrt(eval_r(idx[0])) / (2.0 * M_PI / 1.55)
                    : 0.0;
                // Use k0 from sigma: sigma = (k0*n_target)^2 → k0 = sqrt(sigma)/n_target
                // Actually k0 is not directly available here, so compute from the eigenvalue
                std::cout << "  Iter " << std::setw(3) << iter + 1
                          << ": res = " << std::scientific << std::setprecision(2)
                          << max_residual << std::fixed
                          << "  beta^2_1 = " << std::setprecision(3) << eval_r(idx[0])
                          << std::endl;
            }
        }

        if (max_residual < tol_) {
            converged = true;
            if (myid == 0 && verbose_ > 0) {
                std::cout << "  Converged in " << iter + 1 << " iterations."
                          << std::endl;
            }
            break;
        }
    }

    if (!converged && myid == 0) {
        std::cout << "  WARNING: did not fully converge within "
                  << max_iter_ << " iterations (results may still be usable)."
                  << std::endl;
    }

    // ── Final Rayleigh-Ritz ──────────────────────────────────────────────────
    MOrthogonalize(X, M);
    DenseMatrix Af(nev), Bf(nev);
    for (int j = 0; j < nev; j++) {
        A.Mult(*X[j], Av);
        ApplyBeff(M, C, Ct, D_solver, *X[j], Bv, tmp_z1, tmp_z2, tmp_t);
        for (int i = 0; i < nev; i++) {
            Af(i, j) = InnerProduct(comm_, *X[i], Av);
            Bf(i, j) = InnerProduct(comm_, *X[i], Bv);
        }
    }

    DenseMatrixGeneralizedEigensystem final_eig(Af, Bf, false, true);
    final_eig.Eval();
    Vector &feval_r = final_eig.EigenvaluesRealPart();
    DenseMatrix &fevec = final_eig.RightEigenvectors();

    std::vector<int> fidx(nev);
    std::iota(fidx.begin(), fidx.end(), 0);
    std::sort(fidx.begin(), fidx.end(), [&](int a, int b) {
        return std::abs(feval_r(a) - sigma_) < std::abs(feval_r(b) - sigma_);
    });

    result_.eigenvalues.resize(nev);
    for (auto *v : result_.eigenvectors) delete v;
    result_.eigenvectors.resize(nev);

    for (int j = 0; j < nev; j++) {
        result_.eigenvalues[j] = feval_r(fidx[j]);
        result_.eigenvectors[j] = new HypreParVector(
            comm_, A.GetGlobalNumRows(), A.GetRowStarts());
        *result_.eigenvectors[j] = 0.0;
        for (int k = 0; k < nev; k++) {
            result_.eigenvectors[j]->Add(fevec(k, fidx[j]), *X[k]);
        }
    }

    for (int j = 0; j < block_size; j++) {
        delete X[j];
        delete Y[j];
    }
    delete A_shifted;
    delete Ct_scaled;
    delete S_block;
}

} // namespace eigensolve
