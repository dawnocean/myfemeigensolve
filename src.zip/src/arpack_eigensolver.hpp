#pragma once
#ifdef EIGENSOLVE_USE_ARPACK
#include "eigensolver.hpp"

namespace eigensolve {

/// ARPACK/PARPACK-based block eigensolver using implicitly restarted
/// Arnoldi method with shift-and-invert spectral transformation.
/// Solves the same block generalized eigenvalue problem as the other solvers:
///   [A, C; 0, D] x = beta^2 [M, 0; C^T, 0] x
class ArpackBlockEigensolver : public EigensolverBase {
public:
    ArpackBlockEigensolver(MPI_Comm comm);
    ~ArpackBlockEigensolver() override;

    void SetNumModes(int n) override { num_modes_ = n; }
    void SetShift(double sigma) override { sigma_ = sigma; }
    void SetTolerance(double tol) override { tol_ = tol; }
    void SetMaxIterations(int max_it) override { max_iter_ = max_it; }
    void SetVerbose(int v) override { verbose_ = v; }

    void Solve(mfem::HypreParMatrix &A, mfem::HypreParMatrix &M,
               mfem::HypreParMatrix &C, mfem::HypreParMatrix &Ct,
               mfem::HypreParMatrix &D) override;

    const std::vector<double>& Eigenvalues() const override { return eigenvalues_; }
    const std::vector<mfem::HypreParVector*>& Eigenvectors() const override {
        return eigenvectors_;
    }

private:
    MPI_Comm comm_;
    int num_modes_ = 6;
    double sigma_ = 0.0;
    double tol_ = 1e-6;
    int max_iter_ = 200;
    int verbose_ = 1;

    std::vector<double> eigenvalues_;
    std::vector<mfem::HypreParVector*> eigenvectors_;
};

} // namespace eigensolve

#endif // EIGENSOLVE_USE_ARPACK
