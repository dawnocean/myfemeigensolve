#ifdef EIGENSOLVE_USE_ARPACK
#include "arpack_eigensolver.hpp"
#include <cmath>
#include <algorithm>
#include <numeric>
#include <iostream>
#include <iomanip>
#include <cstring>

// PARPACK Fortran interface (double precision, non-symmetric, parallel)
extern "C" {
void pdnaupd_(MPI_Fint *comm, int *ido, char *bmat, int *n, char *which,
              int *nev, double *tol, double *resid, int *ncv, double *v,
              int *ldv, int *iparam, int *ipntr, double *workd, double *workl,
              int *lworkl, int *info);

void pdneupd_(MPI_Fint *comm, int *rvec, char *howmny, int *select,
              double *dr, double *di, double *z, int *ldz, double *sigmar,
              double *sigmai, double *workev, char *bmat, int *n, char *which,
              int *nev, double *tol, double *resid, int *ncv, double *v,
              int *ldv, int *iparam, int *ipntr, double *workd, double *workl,
              int *lworkl, int *info);
}

namespace eigensolve {

using namespace mfem;

ArpackBlockEigensolver::ArpackBlockEigensolver(MPI_Comm comm)
    : comm_(comm) {}

ArpackBlockEigensolver::~ArpackBlockEigensolver()
{
    for (auto *v : eigenvectors_) delete v;
}

void ArpackBlockEigensolver::Solve(
    HypreParMatrix &A, HypreParMatrix &M,
    HypreParMatrix &C, HypreParMatrix &Ct,
    HypreParMatrix &D)
{
    int myid;
    MPI_Comm_rank(comm_, &myid);

    HYPRE_BigInt n_t = A.GetGlobalNumRows();
    HYPRE_BigInt n_z = D.GetGlobalNumRows();
    int local_n_t = A.GetNumRows();
    int local_n_z = D.GetNumRows();

    // We solve the REDUCED eigenvalue problem on E_t only:
    //   A * e_t = beta^2 * B_eff * e_t
    // where B_eff = M - C * D^{-1} * C^T
    //
    // Using bmat='I' (standard inner product) and mode 1:
    //   OP = inv(A - sigma*B_eff) * B_eff
    //   ARPACK finds theta_i of OP*x = theta*x, where theta = 1/(beta^2 - sigma)
    //   Then beta^2 = sigma + 1/theta
    //
    // OP is applied via the block factorization:
    //   S_block = [A-sigma*M, C; -sigma*C^T, D]
    //   Solve S_block * [y_t; y_z] = [B_eff*x; 0], return y_t
    //   where B_eff*x = M*x - C*D^{-1}*C^T*x

    int nev = num_modes_;
    int ncv = std::min(std::max(2 * nev + 1, 20), (int)n_t);

    if (myid == 0 && verbose_ > 0) {
        std::cout << "\n=== ARPACK (PARPACK) Block Eigensolver ===" << std::endl;
        std::cout << "  ND DOFs (E_t): " << n_t << std::endl;
        std::cout << "  H1 DOFs (E_z): " << n_z << std::endl;
        std::cout << "  Modes requested (NEV): " << nev << std::endl;
        std::cout << "  Arnoldi vectors (NCV): " << ncv << std::endl;
        std::cout << "  Shift (sigma): " << sigma_ << std::endl;
    }

    // ── Form block shifted matrix S = [A-σM, C; -σCᵀ, D] ──────────────────
    HypreParMatrix *A_shifted = Add(1.0, A, -sigma_, M);
    HypreParMatrix *Ct_scaled = new HypreParMatrix(Ct);
    *Ct_scaled *= -sigma_;

    Array2D<const HypreParMatrix*> blocks(2, 2);
    blocks(0, 0) = A_shifted;
    blocks(0, 1) = &C;
    blocks(1, 0) = Ct_scaled;
    blocks(1, 1) = &D;
    HypreParMatrix *S_block = HypreParMatrixFromBlocks(blocks);

    if (myid == 0 && verbose_ > 0) {
        std::cout << "  Factoring block system with SuperLU..." << std::flush;
    }

    SuperLURowLocMatrix S_superlu(*S_block);
    SuperLUSolver block_solver(comm_);
    block_solver.SetPrintStatistics(false);
    block_solver.SetColumnPermutation(superlu::PARMETIS);
    block_solver.SetOperator(S_superlu);

    if (myid == 0 && verbose_ > 0) {
        std::cout << " done." << std::endl;
    }

    // ── Factor D for B_eff evaluation ───────────────────────────────────────
    if (myid == 0 && verbose_ > 0) {
        std::cout << "  Factoring D matrix..." << std::flush;
    }
    SuperLURowLocMatrix D_superlu(D);
    SuperLUSolver D_solver(comm_);
    D_solver.SetPrintStatistics(false);
    D_solver.SetColumnPermutation(superlu::PARMETIS);
    D_solver.SetOperator(D_superlu);
    if (myid == 0 && verbose_ > 0) {
        std::cout << " done." << std::endl;
    }

    // ── Allocate ARPACK work arrays (n_t dimensional, reduced problem) ──────
    int nloc = local_n_t; // ARPACK works on the E_t DOFs only
    int lworkl = 3 * ncv * ncv + 6 * ncv;
    std::vector<double> resid(nloc, 0.0);
    std::vector<double> v(nloc * ncv, 0.0);
    std::vector<double> workd(3 * nloc, 0.0);
    std::vector<double> workl(lworkl, 0.0);
    std::vector<int> iparam(11, 0);
    std::vector<int> ipntr(14, 0);

    int ido = 0;
    char bmat = 'I';         // Standard eigenvalue problem (standard inner product)
    char which[3] = "LM";    // Largest magnitude of theta = closest beta^2 to sigma
    int info = 0;             // Random starting vector

    iparam[0] = 1;           // Exact shifts
    iparam[2] = max_iter_;   // Maximum Arnoldi iterations
    iparam[6] = 1;           // Mode 1: standard (OP = user-supplied operator)

    MPI_Fint fcomm = MPI_Comm_c2f(comm_);

    // Temporary vectors for operator applications
    int block_nloc = local_n_t + local_n_z;
    HypreParVector block_rhs(comm_, S_block->GetGlobalNumRows(),
                             S_block->GetRowStarts());
    HypreParVector block_sol(comm_, S_block->GetGlobalNumRows(),
                             S_block->GetRowStarts());
    HypreParVector x_t(comm_, M.GetGlobalNumRows(), M.GetRowStarts());
    HypreParVector Mx_t(comm_, M.GetGlobalNumRows(), M.GetRowStarts());
    HypreParVector Ctx_t(comm_, D.GetGlobalNumRows(), D.GetRowStarts());
    HypreParVector tmp_z(comm_, D.GetGlobalNumRows(), D.GetRowStarts());
    HypreParVector Cz(comm_, M.GetGlobalNumRows(), M.GetRowStarts());

    if (myid == 0 && verbose_ > 0) {
        std::cout << "  Starting ARPACK reverse communication loop..." << std::endl;
    }

    // ── Reverse communication loop ──────────────────────────────────────────
    int op_count = 0;
    while (true) {
        pdnaupd_(&fcomm, &ido, &bmat, &nloc, which,
                 &nev, &tol_, resid.data(), &ncv, v.data(),
                 &nloc, iparam.data(), ipntr.data(), workd.data(),
                 workl.data(), &lworkl, &info);

        if (ido == -1 || ido == 1) {
            // Compute y = OP*x = inv(A-sigma*B_eff) * B_eff * x
            // where x is at workd[ipntr[0]-1], y goes to workd[ipntr[1]-1]
            double *x_ptr = &workd[ipntr[0] - 1];
            double *y_ptr = &workd[ipntr[1] - 1];

            // Copy x into HypreParVector
            std::memcpy(x_t.GetData(), x_ptr, local_n_t * sizeof(double));

            // Step 1: Compute B_eff*x = M*x - C*D^{-1}*C^T*x
            M.Mult(x_t, Mx_t);          // Mx_t = M * x_t
            Ct.Mult(x_t, Ctx_t);        // Ctx_t = C^T * x_t
            D_solver.Mult(Ctx_t, tmp_z); // tmp_z = D^{-1} * C^T * x_t
            C.Mult(tmp_z, Cz);           // Cz = C * D^{-1} * C^T * x_t
            Mx_t.Add(-1.0, Cz);          // Mx_t = B_eff * x_t

            // Step 2: Solve S_block * [y_t; y_z] = [B_eff*x; 0]
            double *rhs_data = block_rhs.GetData();
            std::memcpy(rhs_data, Mx_t.GetData(), local_n_t * sizeof(double));
            std::memset(rhs_data + local_n_t, 0, local_n_z * sizeof(double));

            block_sol = 0.0;
            block_solver.Mult(block_rhs, block_sol);

            // Extract y_t (first n_t components)
            std::memcpy(y_ptr, block_sol.GetData(), local_n_t * sizeof(double));

            op_count++;
            if (myid == 0 && verbose_ > 0 && op_count % 10 == 0) {
                std::cout << "  ARPACK OP*x count: " << op_count << std::endl;
            }
        } else {
            break;
        }
    }

    if (info < 0) {
        if (myid == 0) {
            std::cerr << "  ARPACK error: pdnaupd returned info = " << info
                      << std::endl;
        }
        delete A_shifted;
        delete Ct_scaled;
        delete S_block;
        return;
    }

    int nconv = iparam[4];
    if (myid == 0 && verbose_ > 0) {
        std::cout << "  ARPACK converged: " << nconv << " eigenvalues in "
                  << iparam[2] << " Arnoldi iterations ("
                  << op_count << " OP*x applications)" << std::endl;
    }

    // ── Extract eigenvalues and eigenvectors ────────────────────────────────
    int rvec = 1;
    char howmny = 'A';
    std::vector<int> select(ncv, 0);
    std::vector<double> dr(nev + 1, 0.0);
    std::vector<double> di(nev + 1, 0.0);
    std::vector<double> z(nloc * (nev + 1), 0.0);
    std::vector<double> workev(3 * ncv, 0.0);
    double sigmar = 0.0; // No ARPACK-level shift (we handle it ourselves)
    double sigmai = 0.0;

    pdneupd_(&fcomm, &rvec, &howmny, select.data(),
             dr.data(), di.data(), z.data(), &nloc, &sigmar,
             &sigmai, workev.data(), &bmat, &nloc, which,
             &nev, &tol_, resid.data(), &ncv, v.data(),
             &nloc, iparam.data(), ipntr.data(), workd.data(),
             workl.data(), &lworkl, &info);

    if (info != 0 && myid == 0) {
        std::cerr << "  ARPACK warning: pdneupd returned info = " << info
                  << std::endl;
    }

    // ── Convert ARPACK eigenvalues to physical eigenvalues ──────────────────
    // ARPACK returned theta = eigenvalue of OP = inv(A-sigma*B_eff)*B_eff
    // Physical eigenvalue: beta^2 = sigma + 1/theta
    // For complex conjugate pairs: use real part of 1/theta

    struct EigPair { double eigenvalue; int index; };
    std::vector<EigPair> valid_pairs;

    if (myid == 0 && verbose_ > 0) {
        std::cout << "  Raw ARPACK eigenvalues (theta = eig of OP):" << std::endl;
    }

    for (int i = 0; i < std::min(nconv, nev); i++) {
        double theta_r = dr[i], theta_i = di[i];
        double theta_mag2 = theta_r * theta_r + theta_i * theta_i;

        if (theta_mag2 < 1e-30) continue; // Skip zero eigenvalues

        // beta^2 = sigma + 1/theta = sigma + theta_r/(|theta|^2) (real part)
        double beta_sq = sigma_ + theta_r / theta_mag2;
        double beta_sq_imag = -theta_i / theta_mag2; // imaginary part of 1/theta

        if (myid == 0 && verbose_ > 0) {
            std::cout << "    theta[" << i << "] = " << std::setprecision(6)
                      << theta_r << " + " << theta_i << "i"
                      << "  -> beta^2 = " << beta_sq;
            if (std::abs(beta_sq_imag) > 1e-6) {
                std::cout << " + " << beta_sq_imag << "i";
            }
            std::cout << std::endl;
        }

        // Keep eigenvalues with small imaginary part and positive real part
        if (std::abs(beta_sq_imag) < 0.01 * std::abs(beta_sq) && beta_sq > 0) {
            valid_pairs.push_back({beta_sq, i});

            // Skip complex conjugate pair
            if (std::abs(theta_i) > 1e-10 && i + 1 < std::min(nconv, nev)) {
                i++; // skip conjugate
            }
        }
    }

    // Sort by distance to sigma (closest first)
    std::sort(valid_pairs.begin(), valid_pairs.end(),
              [this](const EigPair &a, const EigPair &b) {
                  return std::abs(a.eigenvalue - sigma_) <
                         std::abs(b.eigenvalue - sigma_);
              });

    int n_keep = std::min((int)valid_pairs.size(), nev);

    for (auto *ev : eigenvectors_) delete ev;
    eigenvalues_.resize(n_keep);
    eigenvectors_.resize(n_keep);

    for (int j = 0; j < n_keep; j++) {
        eigenvalues_[j] = valid_pairs[j].eigenvalue;
        eigenvectors_[j] = new HypreParVector(
            comm_, A.GetGlobalNumRows(), A.GetRowStarts());

        int idx = valid_pairs[j].index;
        double *evec_data = &z[idx * nloc];
        std::memcpy(eigenvectors_[j]->GetData(), evec_data,
                   local_n_t * sizeof(double));
    }

    if (myid == 0 && verbose_ > 0) {
        std::cout << "  Extracted " << n_keep << " valid eigenvalues" << std::endl;
    }

    delete A_shifted;
    delete Ct_scaled;
    delete S_block;
}

} // namespace eigensolve

#endif // EIGENSOLVE_USE_ARPACK
