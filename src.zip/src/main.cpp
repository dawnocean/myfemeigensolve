#include "mfem.hpp"
#include "mesh_generator.hpp"
#include "waveguide_solver.hpp"
#include <nlohmann/json.hpp>
#include <fstream>
#include <iostream>
#ifdef EIGENSOLVE_USE_SLEPC
#include <slepceps.h>
#endif

using namespace mfem;
using json = nlohmann::json;

int main(int argc, char *argv[])
{
    // Initialize MPI and HYPRE
    Mpi::Init(argc, argv);
    int myid = Mpi::WorldRank();
    Hypre::Init();

#ifdef EIGENSOLVE_USE_SLEPC
    // Initialize SLEPc (and PETSc); MPI already initialized by MFEM
    SlepcInitialize(&argc, &argv, NULL, NULL);
#endif

    // Parse command line: eigensolve [config.json]
    std::string config_file = "config.json";
    if (argc > 1) {
        config_file = argv[1];
    }

    // Read JSON configuration
    json config;
    {
        std::ifstream f(config_file);
        if (!f.is_open()) {
            if (myid == 0) {
                std::cerr << "Error: cannot open config file: " << config_file
                          << std::endl;
            }
            return 1;
        }
        f >> config;
    }

    if (myid == 0) {
        std::cout << "============================================" << std::endl;
        std::cout << "  Electromagnetic Waveguide Mode Solver" << std::endl;
        std::cout << "  (MFEM-based vector FEM eigensolver)" << std::endl;
        std::cout << "============================================" << std::endl;
        std::cout << "Config: " << config_file << std::endl;
    }

    // Generate 2D waveguide mesh
    eigensolve::MeshInfo mesh_info;
    Mesh *serial_mesh = eigensolve::GenerateWaveguideMesh(config, mesh_info);

    // Create parallel mesh
    ParMesh pmesh(MPI_COMM_WORLD, *serial_mesh);
    delete serial_mesh;

    // Solve
    eigensolve::WaveguideSolver solver(pmesh, config, mesh_info);
    auto modes = solver.Solve();

    // Save field output if requested
    bool save_fields = config.value("output", json::object()).value("save_fields", true);
    std::string output_dir = config.value("output", json::object()).value("directory", "results");
    if (save_fields) {
        solver.SaveAllModeFields(output_dir);
        // Export sampled field data and generate PNG plots
        bool save_png = config.value("output", json::object()).value("save_png", true);
        if (save_png) {
            solver.ExportAllModeFieldsPNG(output_dir, modes);
        }
    }

    if (myid == 0) {
        std::cout << "\nDone. Found " << modes.size() << " guided mode(s)."
                  << std::endl;
    }

#ifdef EIGENSOLVE_USE_SLEPC
    SlepcFinalize();
#endif

    return 0;
}
