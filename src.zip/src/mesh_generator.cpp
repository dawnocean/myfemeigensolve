#include "mesh_generator.hpp"
#include <cmath>
#include <iostream>

namespace eigensolve {

using namespace mfem;

// Compute the signed distance from point (x,y) to the waveguide boundary.
// Negative = inside core, positive = outside core.
static double SignedDistToCore(double x, double y,
                               const nlohmann::json &wg_config)
{
    std::string type = wg_config.value("type", "rectangular");
    if (type == "circular") {
        double r = wg_config.value("radius", 0.5);
        return std::sqrt(x * x + y * y) - r;
    } else {
        // Rectangular: signed distance to the box [-w/2,w/2] x [-h/2,h/2]
        double hw = wg_config.value("width", 0.5) / 2.0;
        double hh = wg_config.value("height", 0.22) / 2.0;
        double dx = std::abs(x) - hw;
        double dy = std::abs(y) - hh;
        if (dx <= 0.0 && dy <= 0.0) {
            return std::max(dx, dy); // inside: negative
        }
        double ddx = std::max(dx, 0.0);
        double ddy = std::max(dy, 0.0);
        return std::sqrt(ddx * ddx + ddy * ddy);
    }
}

// Check if element center is inside the waveguide core
static bool IsInsideCore(Mesh &mesh, int elem_idx,
                         const nlohmann::json &wg_config)
{
    Vector center(2);
    mesh.GetElementCenter(elem_idx, center);
    return SignedDistToCore(center(0), center(1), wg_config) < 0.0;
}

// Check if element center is in a PML region
static bool IsInPML(double x, double y,
                    double phys_xmin, double phys_xmax,
                    double phys_ymin, double phys_ymax,
                    const double pml_thickness[4])
{
    // PML on ymin side
    if (pml_thickness[0] > 0 && y < phys_ymin) return true;
    // PML on xmax side
    if (pml_thickness[1] > 0 && x > phys_xmax) return true;
    // PML on ymax side
    if (pml_thickness[2] > 0 && y > phys_ymax) return true;
    // PML on xmin side
    if (pml_thickness[3] > 0 && x < phys_xmin) return true;
    return false;
}

Mesh* GenerateWaveguideMesh(const nlohmann::json &config, MeshInfo &info)
{
    // Domain size (physical region)
    double W = config["domain"]["width"].get<double>();
    double H = config["domain"]["height"].get<double>();

    info.phys_xmin = -W / 2.0;
    info.phys_xmax =  W / 2.0;
    info.phys_ymin = -H / 2.0;
    info.phys_ymax =  H / 2.0;

    // Parse PML configuration from boundary_conditions
    // Boundary attribute convention: ymin=1, xmax=2, ymax=3, xmin=4
    const char* side_names[4] = {"ymin", "xmax", "ymax", "xmin"};
    double default_pml_thickness = 1.0;

    for (int i = 0; i < 4; i++) info.pml_thickness[i] = 0.0;

    if (config.contains("boundary_conditions")) {
        const auto &bc = config["boundary_conditions"];
        double global_pml_t = bc.value("pml_thickness", default_pml_thickness);

        for (int i = 0; i < 4; i++) {
            std::string bc_type = "pec";
            if (bc.contains(side_names[i])) {
                bc_type = bc[side_names[i]].get<std::string>();
            }
            if (bc_type == "pml") {
                info.pml_thickness[i] = global_pml_t;
            }
        }
    }

    // Total domain = physical + PML extensions
    info.total_xmin = info.phys_xmin - info.pml_thickness[3]; // xmin side
    info.total_xmax = info.phys_xmax + info.pml_thickness[1]; // xmax side
    info.total_ymin = info.phys_ymin - info.pml_thickness[0]; // ymin side
    info.total_ymax = info.phys_ymax + info.pml_thickness[2]; // ymax side

    double total_W = info.total_xmax - info.total_xmin;
    double total_H = info.total_ymax - info.total_ymin;

    // Element type
    std::string elem_str = config["solver"].value("element_type", "triangle");
    Element::Type elem_type = (elem_str == "quad" || elem_str == "quadrilateral")
                                  ? Element::QUADRILATERAL
                                  : Element::TRIANGLE;

    // Initial coarse mesh resolution: ~40 elements across physical domain,
    // plus extra for PML regions
    int nx_phys = 40, ny_phys = 40;
    int nx = nx_phys + (int)(info.pml_thickness[3] / W * nx_phys)
                     + (int)(info.pml_thickness[1] / W * nx_phys);
    int ny = ny_phys + (int)(info.pml_thickness[0] / H * ny_phys)
                     + (int)(info.pml_thickness[2] / H * ny_phys);
    if (nx < nx_phys) nx = nx_phys;
    if (ny < ny_phys) ny = ny_phys;

    // Create the Cartesian mesh [0, total_W] x [0, total_H]
    Mesh *mesh = new Mesh(Mesh::MakeCartesian2D(nx, ny, elem_type, false,
                                                 total_W, total_H));

    // Shift so that mesh spans [total_xmin, total_xmax] x [total_ymin, total_ymax]
    for (int i = 0; i < mesh->GetNV(); i++) {
        double *v = mesh->GetVertex(i);
        v[0] += info.total_xmin;
        v[1] += info.total_ymin;
    }

    const auto &wg = config["waveguide"];

    // Assign material attributes:
    // 1 = core, 2 = cladding, 3 = PML
    for (int i = 0; i < mesh->GetNE(); i++) {
        Vector center(2);
        mesh->GetElementCenter(i, center);
        if (IsInPML(center(0), center(1),
                    info.phys_xmin, info.phys_xmax,
                    info.phys_ymin, info.phys_ymax,
                    info.pml_thickness)) {
            mesh->SetAttribute(i, 3);
        } else if (IsInsideCore(*mesh, i, wg)) {
            mesh->SetAttribute(i, 1);
        } else {
            mesh->SetAttribute(i, 2);
        }
    }

    // Adaptive refinement near the core-cladding interface
    int n_ref = config["solver"].value("refinements", 3);
    for (int ref = 0; ref < n_ref; ref++) {
        Array<int> marked_elements;

        double h_est = std::min(W / nx_phys, H / ny_phys) / std::pow(2.0, ref);
        double threshold = 1.5 * h_est;

        for (int i = 0; i < mesh->GetNE(); i++) {
            Vector center(2);
            mesh->GetElementCenter(i, center);
            double dist = std::abs(SignedDistToCore(center(0), center(1), wg));
            if (dist < threshold) {
                marked_elements.Append(i);
            }
        }

        if (marked_elements.Size() > 0) {
            mesh->GeneralRefinement(marked_elements);
        }

        // Re-assign attributes after refinement
        for (int i = 0; i < mesh->GetNE(); i++) {
            Vector center(2);
            mesh->GetElementCenter(i, center);
            if (IsInPML(center(0), center(1),
                        info.phys_xmin, info.phys_xmax,
                        info.phys_ymin, info.phys_ymax,
                        info.pml_thickness)) {
                mesh->SetAttribute(i, 3);
            } else if (IsInsideCore(*mesh, i, wg)) {
                mesh->SetAttribute(i, 1);
            } else {
                mesh->SetAttribute(i, 2);
            }
        }
    }

    mesh->SetAttributes();

    int myid = 0;
    MPI_Comm_rank(MPI_COMM_WORLD, &myid);
    if (myid == 0) {
        std::cout << "Mesh generated: " << mesh->GetNE() << " elements, "
                  << mesh->GetNEdges() << " edges" << std::endl;
        bool has_pml = false;
        for (int i = 0; i < 4; i++) {
            if (info.pml_thickness[i] > 0) has_pml = true;
        }
        if (has_pml) {
            std::cout << "  PML thickness: [ymin=" << info.pml_thickness[0]
                      << ", xmax=" << info.pml_thickness[1]
                      << ", ymax=" << info.pml_thickness[2]
                      << ", xmin=" << info.pml_thickness[3] << "]" << std::endl;
            std::cout << "  Total domain: [" << info.total_xmin << ", "
                      << info.total_xmax << "] x [" << info.total_ymin
                      << ", " << info.total_ymax << "]" << std::endl;
        }
    }

    return mesh;
}

} // namespace eigensolve
