#pragma once
#include "mfem.hpp"
#include <vector>

namespace eigensolve {

struct EigenResult {
    std::vector<double> eigenvalues;
    std::vector<mfem::HypreParVector*> eigenvectors;
};

/// Abstract interface for waveguide eigensolvers.
///
/// Solves the block eigenvalue problem:
///   [A    C ] [e_t]       [M    0 ] [e_t]
///   [0    D ] [ẽ_z]  = β² [C^T  0 ] [ẽ_z]
class EigensolverBase {
public:
    virtual ~EigensolverBase() = default;

    virtual void SetNumModes(int n) = 0;
    virtual void SetShift(double sigma) = 0;
    virtual void SetTolerance(double tol) = 0;
    virtual void SetMaxIterations(int max_it) = 0;
    virtual void SetVerbose(int v) = 0;

    virtual void Solve(mfem::HypreParMatrix &A, mfem::HypreParMatrix &M,
                       mfem::HypreParMatrix &C, mfem::HypreParMatrix &Ct,
                       mfem::HypreParMatrix &D) = 0;

    virtual const std::vector<double>& Eigenvalues() const = 0;
    virtual const std::vector<mfem::HypreParVector*>& Eigenvectors() const = 0;
};

/// Built-in eigensolver using block shift-and-invert subspace iteration
/// with SuperLU direct factorization.
class BlockEigensolver : public EigensolverBase {
public:
    BlockEigensolver(MPI_Comm comm);
    ~BlockEigensolver() override;

    void SetNumModes(int n) override { num_modes_ = n; }
    void SetShift(double sigma) override { sigma_ = sigma; }
    void SetTolerance(double tol) override { tol_ = tol; }
    void SetMaxIterations(int max_it) override { max_iter_ = max_it; }
    void SetVerbose(int v) override { verbose_ = v; }

    void Solve(mfem::HypreParMatrix &A, mfem::HypreParMatrix &M,
               mfem::HypreParMatrix &C, mfem::HypreParMatrix &Ct,
               mfem::HypreParMatrix &D) override;

    const std::vector<double>& Eigenvalues() const override { return result_.eigenvalues; }
    const std::vector<mfem::HypreParVector*>& Eigenvectors() const override {
        return result_.eigenvectors;
    }

private:
    MPI_Comm comm_;
    int num_modes_ = 6;
    double sigma_ = 0.0;
    double tol_ = 1e-6;
    int max_iter_ = 200;
    int verbose_ = 1;
    EigenResult result_;

    void MOrthogonalize(std::vector<mfem::HypreParVector*> &vecs,
                        mfem::HypreParMatrix &M);
};

} // namespace eigensolve
