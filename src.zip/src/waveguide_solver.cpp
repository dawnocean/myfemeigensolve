#include "waveguide_solver.hpp"
#ifdef EIGENSOLVE_USE_SLEPC
#include "slepc_eigensolver.hpp"
#endif
#ifdef EIGENSOLVE_USE_ARPACK
#include "arpack_eigensolver.hpp"
#endif
#include <cmath>
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <filesystem>
#include <fstream>
#include <sstream>

namespace eigensolve {

using namespace mfem;

WaveguideSolver::WaveguideSolver(ParMesh &pmesh, const nlohmann::json &config,
                                 const MeshInfo &mesh_info)
    : pmesh_(pmesh), config_(config), mesh_info_(mesh_info)
{
    wavelength_ = config_["wavelength"].get<double>();
    k0_ = 2.0 * M_PI / wavelength_;
    n_core_ = config_["materials"]["core_index"].get<double>();
    n_clad_ = config_["materials"]["cladding_index"].get<double>();

    for (int i = 0; i < 4; i++) {
        if (mesh_info_.pml_thickness[i] > 0) { has_pml_ = true; break; }
    }

    int order = config_["solver"].value("order", 2);
    int dim = pmesh_.Dimension();

    // Nedelec (edge) space for transverse E_t
    nd_fec_ = new ND_FECollection(order, dim);
    nd_fespace_ = new ParFiniteElementSpace(&pmesh_, nd_fec_);

    // H1 (nodal) space for longitudinal E_z
    h1_fec_ = new H1_FECollection(order, dim);
    h1_fespace_ = new ParFiniteElementSpace(&pmesh_, h1_fec_);

    int myid;
    MPI_Comm_rank(pmesh_.GetComm(), &myid);
    if (myid == 0) {
        std::cout << "Waveguide solver setup:" << std::endl;
        std::cout << "  Wavelength: " << wavelength_ << " um" << std::endl;
        std::cout << "  k0: " << k0_ << " um^-1" << std::endl;
        std::cout << "  Core index: " << n_core_ << std::endl;
        std::cout << "  Cladding index: " << n_clad_ << std::endl;
        std::cout << "  FE order: " << order << std::endl;
        std::cout << "  ND DOFs (E_t): " << nd_fespace_->GlobalTrueVSize() << std::endl;
        std::cout << "  H1 DOFs (E_z): " << h1_fespace_->GlobalTrueVSize() << std::endl;

        // Print boundary conditions
        if (config_.contains("boundary_conditions")) {
            const auto &bc = config_["boundary_conditions"];
            const char* side_names[4] = {"ymin", "xmax", "ymax", "xmin"};
            std::cout << "  Boundary conditions:";
            for (int i = 0; i < 4; i++) {
                std::string bc_type = "pec";
                if (bc.contains(side_names[i])) {
                    bc_type = bc[side_names[i]].get<std::string>();
                }
                std::cout << " " << side_names[i] << "=" << bc_type;
            }
            std::cout << std::endl;
        } else {
            std::cout << "  Boundary conditions: PEC (all)" << std::endl;
        }
        if (has_pml_) {
            std::cout << "  PML: enabled" << std::endl;
        }
    }

    AssembleMatrices();
}

WaveguideSolver::~WaveguideSolver()
{
    delete eigensolver_;
    delete A_;
    delete K_;
    delete M_eps_;
    delete M_;
    delete D_;
    delete S_zz_;
    delete M_eps_zz_;
    delete C_;
    delete Ct_;
    delete nd_fespace_;
    delete nd_fec_;
    delete h1_fespace_;
    delete h1_fec_;
}

void WaveguideSolver::AssembleMatrices()
{
    // Material coefficient: epsilon_r = n^2
    // Attributes: 1=core, 2=cladding, 3=PML (uses cladding epsilon)
    int max_attr = pmesh_.attributes.Max();
    Vector eps_vals(max_attr);
    eps_vals = n_clad_ * n_clad_;
    eps_vals(0) = n_core_ * n_core_;  // attribute 1 = core
    // attribute 2 = cladding (already set)
    // attribute 3 = PML (uses cladding epsilon, already set)
    PWConstCoefficient epsilon_coeff(eps_vals);
    ConstantCoefficient one(1.0);

    // ── Boundary conditions ──────────────────────────────────────────────────
    // Parse per-boundary BC types.
    // Boundary attributes from MakeCartesian2D: ymin=1, xmax=2, ymax=3, xmin=4
    // BC types:
    //   "pec" (electric wall):  n×E=0   → essential BC on ND (E_t=0) and H1 (E_z=0)
    //   "pmc" (magnetic wall):  n×H=0   → natural BC (no constraint)
    //   "symmetric":            same as PEC (electric wall, E_t tangential=0, E_z=0)
    //   "antisymmetric":        same as PMC (magnetic wall, natural BC)
    //   "pml":                  PEC on outer PML boundary (absorbing layer handles it)

    int max_bdr = pmesh_.bdr_attributes.Size() > 0 ? pmesh_.bdr_attributes.Max() : 0;
    Array<int> nd_ess_bdr(max_bdr), h1_ess_bdr(max_bdr);
    nd_ess_bdr = 0;
    h1_ess_bdr = 0;

    if (max_bdr > 0) {
        const char* side_names[4] = {"ymin", "xmax", "ymax", "xmin"};

        for (int i = 0; i < 4; i++) {
            std::string bc_type = "pec"; // default
            if (config_.contains("boundary_conditions") &&
                config_["boundary_conditions"].contains(side_names[i])) {
                bc_type = config_["boundary_conditions"][side_names[i]].get<std::string>();
            }

            int bdr_attr = i + 1; // ymin=1, xmax=2, ymax=3, xmin=4
            if (bdr_attr > max_bdr) continue;

            if (bc_type == "pec" || bc_type == "symmetric" || bc_type == "pml") {
                // PEC / electric wall / PML outer: n×E_t = 0, E_z = 0
                nd_ess_bdr[bdr_attr - 1] = 1;
                h1_ess_bdr[bdr_attr - 1] = 1;
            }
            // "pmc" / "antisymmetric": natural BC, no essential DOFs
        }
    }

    Array<int> nd_ess_tdofs, h1_ess_tdofs;
    nd_fespace_->GetEssentialTrueDofs(nd_ess_bdr, nd_ess_tdofs);
    h1_fespace_->GetEssentialTrueDofs(h1_ess_bdr, h1_ess_tdofs);

    // ── PML-aware coefficients ───────────────────────────────────────────────
    // For PML, the bilinear forms are modified:
    //   curl-curl: ∫ (1/det) (∇×E)·(∇×F) → use Λ^{-1} tensor for CurlCurl
    //     In 2D, CurlCurl for ND becomes: ∫ (s_x*s_y)^{-1} curl(E_t) curl(F_t)
    //     But since CurlCurlIntegrator takes a scalar, we use 1/(s_x*s_y).
    //   vector mass:  ∫ ε Λ_t E·F where Λ_t = diag(s_y/s_x, s_x/s_y)
    //   scalar diff:  ∫ Λ^{-1}_t ∇E_z · ∇F_z where Λ^{-1}_t = diag(s_x/s_y, s_y/s_x)
    //   scalar mass:  ∫ ε s_x*s_y E_z F_z
    //
    // Without PML, s_x = s_y = 1, so all reduce to standard forms.

    PMLStretchingFunction pml_func(mesh_info_);

    // Curl-curl coefficient: 1/(s_x * s_y)
    PMLDetCoefficient pml_det(pml_func);
    // We need 1/det for curl-curl
    class InvDetCoeff : public Coefficient {
    public:
        InvDetCoeff(PMLDetCoefficient &det) : det_(det) {}
        double Eval(ElementTransformation &T, const IntegrationPoint &ip) override {
            return 1.0 / det_.Eval(T, ip);
        }
    private:
        PMLDetCoefficient &det_;
    };
    InvDetCoeff inv_det_coeff(pml_det);

    // Tensor for vector mass: diag(s_y/s_x, s_x/s_y) * epsilon
    PMLTensorCoefficient pml_tensor(pml_func);
    ScaledMatrixCoefficient eps_pml_tensor(pml_tensor, epsilon_coeff);

    // Tensor for vector mass (unit): diag(s_y/s_x, s_x/s_y)
    // (no epsilon scaling, for unit mass M)

    // Inverse tensor for scalar diffusion: diag(s_x/s_y, s_y/s_x)
    PMLInvTensorCoefficient pml_inv_tensor(pml_func);

    // Scalar PML coefficient for scalar mass: s_x * s_y * epsilon
    PMLScalarCoefficient eps_pml_scalar(pml_func, epsilon_coeff);

    // Det coefficient for scalar: s_x * s_y (unit)
    PMLScalarCoefficient pml_det_unit(pml_func, one);

    // ── ND×ND matrices ──────────────────────────────────────────────────────
    // Curl-curl stiffness K: ∫ (1/(s_x*s_y)) curl(E_t) curl(F_t)
    ParBilinearForm k_form(nd_fespace_);
    if (has_pml_) {
        k_form.AddDomainIntegrator(new CurlCurlIntegrator(inv_det_coeff));
    } else {
        k_form.AddDomainIntegrator(new CurlCurlIntegrator(one));
    }
    k_form.Assemble();
    k_form.EliminateEssentialBCDiag(nd_ess_bdr, 1.0);
    k_form.Finalize();
    K_ = k_form.ParallelAssemble();

    // Epsilon-weighted vector mass M_eps (ND): ∫ ε Λ_t E·F
    ParBilinearForm meps_form(nd_fespace_);
    if (has_pml_) {
        meps_form.AddDomainIntegrator(new VectorFEMassIntegrator(eps_pml_tensor));
    } else {
        meps_form.AddDomainIntegrator(new VectorFEMassIntegrator(epsilon_coeff));
    }
    meps_form.Assemble();
    meps_form.EliminateEssentialBCDiag(nd_ess_bdr, 0.0);
    meps_form.Finalize();
    M_eps_ = meps_form.ParallelAssemble();

    // Unit vector mass M (ND): ∫ Λ_t E·F
    ParBilinearForm m_form(nd_fespace_);
    if (has_pml_) {
        m_form.AddDomainIntegrator(new VectorFEMassIntegrator(pml_tensor));
    } else {
        m_form.AddDomainIntegrator(new VectorFEMassIntegrator(one));
    }
    m_form.Assemble();
    m_form.EliminateEssentialBCDiag(nd_ess_bdr, 0.0);
    m_form.Finalize();
    M_ = m_form.ParallelAssemble();

    // ── H1×H1 matrices ─────────────────────────────────────────────────────
    // Scalar stiffness S_zz: ∫ Λ^{-1}_t ∇φ·∇ψ
    ParBilinearForm szz_form(h1_fespace_);
    if (has_pml_) {
        szz_form.AddDomainIntegrator(new DiffusionIntegrator(pml_inv_tensor));
    } else {
        szz_form.AddDomainIntegrator(new DiffusionIntegrator(one));
    }
    szz_form.Assemble();
    szz_form.EliminateEssentialBCDiag(h1_ess_bdr, 1.0);
    szz_form.Finalize();
    S_zz_ = szz_form.ParallelAssemble();

    // Epsilon-weighted scalar mass M_eps_zz: ∫ ε s_x s_y φ ψ
    ParBilinearForm mzz_form(h1_fespace_);
    if (has_pml_) {
        mzz_form.AddDomainIntegrator(new MassIntegrator(eps_pml_scalar));
    } else {
        mzz_form.AddDomainIntegrator(new MassIntegrator(epsilon_coeff));
    }
    mzz_form.Assemble();
    mzz_form.EliminateEssentialBCDiag(h1_ess_bdr, 0.0);
    mzz_form.Finalize();
    M_eps_zz_ = mzz_form.ParallelAssemble();

    // D = S_zz - k0^2 * M_eps_zz
    D_ = Add(1.0, *S_zz_, -k0_ * k0_, *M_eps_zz_);

    // ── Coupling matrix C (ND × H1) ────────────────────────────────────────
    // C: ∫ (∇φ) · w dA, where φ ∈ H1 (trial), w ∈ ND (test)
    // For PML: C: ∫ Λ^{-1}_t (∇φ) · w  — but the standard MixedVectorGradient
    // doesn't support matrix coefficients easily. For simplicity with real PML,
    // we use the unit coupling (PML primarily affects the diagonal blocks).
    ParMixedBilinearForm c_form(h1_fespace_, nd_fespace_);
    c_form.AddDomainIntegrator(new MixedVectorGradientIntegrator(one));
    c_form.Assemble();

    // Eliminate essential BCs for the mixed form
    {
        Vector sol_h1(h1_fespace_->GetVSize()); sol_h1 = 0.0;
        Vector rhs_nd(nd_fespace_->GetVSize()); rhs_nd = 0.0;
        c_form.EliminateTrialDofs(h1_ess_bdr, sol_h1, rhs_nd);
    }
    c_form.Finalize();
    C_ = c_form.ParallelAssemble();
    Ct_ = C_->Transpose();

    // ── Composite matrices ──────────────────────────────────────────────────
    // A = k0^2 * M_eps - K
    A_ = Add(k0_ * k0_, *M_eps_, -1.0, *K_);

}

std::vector<ModeResult> WaveguideSolver::Solve()
{
    int nev = config_["solver"].value("num_modes", 6);
    double target_neff = config_["solver"].value("target_neff",
                                                 (n_core_ + n_clad_) / 2.0);
    double tol = config_["solver"].value("tolerance", 1e-6);
    int max_iter = config_["solver"].value("max_iterations", 200);

    double sigma = (k0_ * target_neff) * (k0_ * target_neff);

    std::string solver_type = config_["solver"].value("eigensolver", "builtin");

    if (solver_type == "slepc") {
#ifdef EIGENSOLVE_USE_SLEPC
        eigensolver_ = new SlepcBlockEigensolver(pmesh_.GetComm());
#else
        if (Mpi::Root()) {
            std::cerr << "Error: SLEPc support not compiled. "
                      << "Rebuild with -DEIGENSOLVE_USE_SLEPC=ON" << std::endl;
            std::cerr << "Falling back to builtin solver." << std::endl;
        }
        eigensolver_ = new BlockEigensolver(pmesh_.GetComm());
#endif
    } else if (solver_type == "arpack") {
#ifdef EIGENSOLVE_USE_ARPACK
        eigensolver_ = new ArpackBlockEigensolver(pmesh_.GetComm());
#else
        if (Mpi::Root()) {
            std::cerr << "Error: ARPACK support not compiled. "
                      << "Rebuild with -DEIGENSOLVE_USE_ARPACK=ON" << std::endl;
            std::cerr << "Falling back to builtin solver." << std::endl;
        }
        eigensolver_ = new BlockEigensolver(pmesh_.GetComm());
#endif
    } else {
        eigensolver_ = new BlockEigensolver(pmesh_.GetComm());
    }

    eigensolver_->SetNumModes(nev);
    eigensolver_->SetShift(sigma);
    eigensolver_->SetTolerance(tol);
    eigensolver_->SetMaxIterations(max_iter);
    eigensolver_->SetVerbose(1);

    eigensolver_->Solve(*A_, *M_, *C_, *Ct_, *D_);

    // Process results
    const auto &eigenvalues = eigensolver_->Eigenvalues();
    std::vector<ModeResult> modes;

    for (int i = 0; i < (int)eigenvalues.size(); i++) {
        double beta_sq = eigenvalues[i];
        if (beta_sq <= 0.0) continue;

        ModeResult mode;
        mode.mode_number = i;
        mode.beta_squared = beta_sq;
        mode.beta = std::sqrt(beta_sq);
        mode.neff = mode.beta / k0_;

        if (mode.neff > n_clad_ * 0.9 && mode.neff < n_core_ * 1.1) {
            modes.push_back(mode);
        }
    }

    std::sort(modes.begin(), modes.end(),
              [](const ModeResult &a, const ModeResult &b) {
                  return a.neff > b.neff;
              });

    for (int i = 0; i < (int)modes.size(); i++) {
        modes[i].mode_number = i + 1;
    }

    int myid;
    MPI_Comm_rank(pmesh_.GetComm(), &myid);
    if (myid == 0) {
        std::cout << "\n╔═══════════════════════════════════════════════════════╗"
                  << std::endl;
        std::cout << "║           Waveguide Mode Analysis Results             ║"
                  << std::endl;
        std::cout << "╠═══════╦═══════════════╦═══════════════╦═══════════════╣"
                  << std::endl;
        std::cout << "║ Mode  ║     n_eff     ║    beta       ║   beta^2      ║"
                  << std::endl;
        std::cout << "║       ║               ║  (1/um)       ║  (1/um^2)     ║"
                  << std::endl;
        std::cout << "╠═══════╬═══════════════╬═══════════════╬═══════════════╣"
                  << std::endl;
        for (const auto &m : modes) {
            std::cout << "║ " << std::setw(5) << m.mode_number
                      << " ║ " << std::setw(13) << std::fixed
                      << std::setprecision(8) << m.neff
                      << " ║ " << std::setw(13) << std::setprecision(6)
                      << m.beta
                      << " ║ " << std::setw(13) << std::setprecision(4)
                      << m.beta_squared << " ║" << std::endl;
        }
        std::cout << "╚═══════╩═══════════════╩═══════════════╩═══════════════╝"
                  << std::endl;
    }

    return modes;
}

void WaveguideSolver::SaveModeField(int mode_idx, const std::string &output_dir)
{
    if (!eigensolver_ || mode_idx >= (int)eigensolver_->Eigenvectors().size()) {
        return;
    }

    const auto *evec = eigensolver_->Eigenvectors()[mode_idx];

    ParGridFunction gf(nd_fespace_);
    gf.SetFromTrueDofs(*evec);

    std::string coll_name = "mode_" + std::to_string(mode_idx);
    ParaViewDataCollection pv(coll_name, &pmesh_);
    pv.SetPrefixPath(output_dir);
    pv.SetLevelsOfDetail(config_["solver"].value("order", 2));
    pv.SetHighOrderOutput(true);
    pv.SetDataFormat(VTKFormat::BINARY);
    pv.RegisterField("Et", &gf);
    pv.SetCycle(0);
    pv.SetTime(0.0);
    pv.Save();
}

void WaveguideSolver::SaveAllModeFields(const std::string &output_dir)
{
    int myid;
    MPI_Comm_rank(pmesh_.GetComm(), &myid);

    if (myid == 0) {
        std::filesystem::create_directories(output_dir);
    }
    MPI_Barrier(pmesh_.GetComm());

    int nev = eigensolver_ ? (int)eigensolver_->Eigenvectors().size() : 0;
    for (int i = 0; i < nev; i++) {
        SaveModeField(i, output_dir);
    }

    if (myid == 0 && nev > 0) {
        std::cout << "\nField data saved to: " << output_dir << "/" << std::endl;
    }
}

void WaveguideSolver::ExportModeFieldGrid(int mode_idx,
                                          const std::string &output_dir,
                                          const ModeResult &mode_info,
                                          int nx, int ny)
{
    if (!eigensolver_ || mode_idx >= (int)eigensolver_->Eigenvectors().size()) {
        return;
    }

    int myid;
    MPI_Comm_rank(pmesh_.GetComm(), &myid);

    const auto *evec = eigensolver_->Eigenvectors()[mode_idx];
    ParGridFunction gf(nd_fespace_);
    gf.SetFromTrueDofs(*evec);

    // Sample on the physical domain (exclude PML for visualization)
    double xmin = mesh_info_.phys_xmin;
    double xmax = mesh_info_.phys_xmax;
    double ymin = mesh_info_.phys_ymin;
    double ymax = mesh_info_.phys_ymax;

    double dx = (xmax - xmin) / (nx - 1);
    double dy = (ymax - ymin) / (ny - 1);

    // Build sample points matrix: (sdim x npts)
    int npts = nx * ny;
    DenseMatrix point_mat(2, npts);
    for (int i = 0; i < nx; i++) {
        for (int j = 0; j < ny; j++) {
            int idx = i * ny + j;
            point_mat(0, idx) = xmin + i * dx;
            point_mat(1, idx) = ymin + j * dy;
        }
    }

    // Find which elements contain each point
    Array<int> elem_ids(npts);
    Array<IntegrationPoint> ips(npts);
    pmesh_.FindPoints(point_mat, elem_ids, ips, false);

    // Evaluate the vector field at each point
    std::vector<double> ex_data(npts, 0.0), ey_data(npts, 0.0);
    Vector val;
    for (int k = 0; k < npts; k++) {
        if (elem_ids[k] >= 0) {
            gf.GetVectorValue(elem_ids[k], ips[k], val);
            ex_data[k] = val(0);
            ey_data[k] = val(1);
        }
    }

    // Only rank 0 writes the file
    if (myid == 0) {
        std::string fname = output_dir + "/mode_" + std::to_string(mode_idx) + ".dat";
        std::ofstream ofs(fname);
        ofs << std::setprecision(12);
        ofs << nx << " " << ny << "\n";
        ofs << xmin << " " << xmax << " " << ymin << " " << ymax << "\n";
        ofs << mode_info.neff << " " << mode_info.beta << " "
            << mode_info.mode_number << "\n";
        for (int k = 0; k < npts; k++) {
            ofs << ex_data[k] << " " << ey_data[k] << "\n";
        }
        ofs.close();
    }
}

void WaveguideSolver::ExportAllModeFieldsPNG(const std::string &output_dir,
                                             const std::vector<ModeResult> &modes)
{
    int myid;
    MPI_Comm_rank(pmesh_.GetComm(), &myid);

    if (myid == 0) {
        std::filesystem::create_directories(output_dir);
    }
    MPI_Barrier(pmesh_.GetComm());

    int nev = eigensolver_ ? (int)eigensolver_->Eigenvectors().size() : 0;
    int nmodes = std::min(nev, (int)modes.size());

    for (int i = 0; i < nmodes; i++) {
        ExportModeFieldGrid(i, output_dir, modes[i]);
    }

    // Call Python script to generate PNG on rank 0
    if (myid == 0 && nmodes > 0) {
        // Find the script relative to the executable or in known locations
        std::string script_paths[] = {
            "plot_modes.py",
            "../plot_modes.py",
        };
        std::string script;
        for (const auto &p : script_paths) {
            if (std::filesystem::exists(p)) {
                script = p;
                break;
            }
        }
        if (!script.empty()) {
            std::string cmd = "python3 " + script + " " + output_dir;
            std::cout << "\nGenerating PNG plots: " << cmd << std::endl;
            int ret = std::system(cmd.c_str());
            if (ret == 0) {
                std::cout << "PNG plots saved to: " << output_dir << "/" << std::endl;
            } else {
                std::cerr << "Warning: PNG plot generation failed (return code "
                          << ret << ")" << std::endl;
            }
        } else {
            std::cout << "\nNote: plot_modes.py not found. Run manually:\n"
                      << "  python3 plot_modes.py " << output_dir << std::endl;
        }
    }
}

} // namespace eigensolve
