#ifdef EIGENSOLVE_USE_SLEPC

#include "slepc_eigensolver.hpp"
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <cmath>

namespace eigensolve {

using namespace mfem;

SlepcBlockEigensolver::SlepcBlockEigensolver(MPI_Comm comm) : comm_(comm) {}

SlepcBlockEigensolver::~SlepcBlockEigensolver()
{
    for (auto *v : eigenvectors_) delete v;
}

void SlepcBlockEigensolver::InsertHypreBlock(
    Mat P, HypreParMatrix &H, PetscInt row_offset, PetscInt col_offset)
{
    // Extract diagonal and off-diagonal CSR blocks via MFEM API
    SparseMatrix diag_sm, offd_sm;
    HYPRE_BigInt *cmap;
    H.GetDiag(diag_sm);
    H.GetOffd(offd_sm, cmap);

    int local_rows = diag_sm.Height();
    HYPRE_BigInt first_row = H.GetRowStarts()[0];
    HYPRE_BigInt first_col_diag = H.GetColStarts()[0];

    // Insert diagonal block entries
    for (int i = 0; i < local_rows; i++) {
        PetscInt grow = row_offset + first_row + i;
        int nnz = diag_sm.RowSize(i);
        const int *cols = diag_sm.GetRowColumns(i);
        const double *vals = diag_sm.GetRowEntries(i);
        for (int j = 0; j < nnz; j++) {
            PetscInt gcol = col_offset + first_col_diag + cols[j];
            MatSetValue(P, grow, gcol, (PetscScalar)vals[j], INSERT_VALUES);
        }
    }

    // Insert off-diagonal block entries
    int offd_ncols = offd_sm.Width();
    if (offd_ncols > 0 && cmap) {
        for (int i = 0; i < local_rows; i++) {
            PetscInt grow = row_offset + first_row + i;
            int nnz = offd_sm.RowSize(i);
            const int *cols = offd_sm.GetRowColumns(i);
            const double *vals = offd_sm.GetRowEntries(i);
            for (int j = 0; j < nnz; j++) {
                PetscInt gcol = col_offset + cmap[cols[j]];
                MatSetValue(P, grow, gcol, (PetscScalar)vals[j], INSERT_VALUES);
            }
        }
    }
}

Mat SlepcBlockEigensolver::FormPetscBlockMatrix(
    MPI_Comm comm, HypreParMatrix *blocks[2][2],
    HYPRE_BigInt nt_global, HYPRE_BigInt nz_global,
    int local_nt, int local_nz)
{
    PetscInt N = (PetscInt)(nt_global + nz_global);
    PetscInt local_n = local_nt + local_nz;

    Mat P;
    MatCreate(comm, &P);
    MatSetSizes(P, local_n, local_n, N, N);
    MatSetType(P, MATAIJ);  // PETSc chooses SeqAIJ or MPIAIJ based on np
    MatSetUp(P);
    MatSetOption(P, MAT_NEW_NONZERO_ALLOCATION_ERR, PETSC_FALSE);

    // Insert values from each non-null block
    HYPRE_BigInt row_offsets[2] = {0, nt_global};

    for (int br = 0; br < 2; br++) {
        for (int bc = 0; bc < 2; bc++) {
            if (!blocks[br][bc]) continue;
            InsertHypreBlock(P, *blocks[br][bc], row_offsets[br], row_offsets[bc]);
        }
    }

    MatAssemblyBegin(P, MAT_FINAL_ASSEMBLY);
    MatAssemblyEnd(P, MAT_FINAL_ASSEMBLY);

    return P;
}

void SlepcBlockEigensolver::Solve(
    HypreParMatrix &A, HypreParMatrix &M,
    HypreParMatrix &C, HypreParMatrix &Ct,
    HypreParMatrix &D)
{
    int myid;
    MPI_Comm_rank(comm_, &myid);

    HYPRE_BigInt nt_global = A.GetGlobalNumRows();
    HYPRE_BigInt nz_global = D.GetGlobalNumRows();
    int local_nt = A.GetNumRows();
    int local_nz = D.GetNumRows();

    if (myid == 0 && verbose_ > 0) {
        std::cout << "\n=== SLEPc Eigensolver ===" << std::endl;
        std::cout << "  ND DOFs (E_t): " << nt_global << std::endl;
        std::cout << "  H1 DOFs (E_z): " << nz_global << std::endl;
        std::cout << "  Total block DOFs: " << nt_global + nz_global << std::endl;
        std::cout << "  Modes requested: " << num_modes_ << std::endl;
        std::cout << "  Shift (sigma): " << sigma_ << std::endl;
    }

    // ── Form block matrices ─────────────────────────────────────────────────
    // LHS = [A, C; 0, D],  RHS = [M, 0; C^T, 0]
    HypreParMatrix *L_blocks[2][2] = {{&A, &C}, {nullptr, &D}};
    HypreParMatrix *R_blocks[2][2] = {{&M, nullptr}, {&Ct, nullptr}};

    if (myid == 0 && verbose_ > 0) {
        std::cout << "  Assembling PETSc block matrices..." << std::flush;
    }

    Mat L = FormPetscBlockMatrix(comm_, L_blocks,
                                 nt_global, nz_global, local_nt, local_nz);
    Mat R = FormPetscBlockMatrix(comm_, R_blocks,
                                 nt_global, nz_global, local_nt, local_nz);

    if (myid == 0 && verbose_ > 0) {
        std::cout << " done." << std::endl;
    }

    // ── Configure SLEPc EPS ─────────────────────────────────────────────────
    EPS eps;
    EPSCreate(comm_, &eps);
    EPSSetOperators(eps, L, R);
    EPSSetProblemType(eps, EPS_GNHEP);
    EPSSetType(eps, EPSKRYLOVSCHUR);
    EPSSetWhichEigenpairs(eps, EPS_TARGET_MAGNITUDE);
    EPSSetTarget(eps, (PetscScalar)sigma_);
    EPSSetDimensions(eps, num_modes_, PETSC_DEFAULT, PETSC_DEFAULT);
    EPSSetTolerances(eps, (PetscReal)tol_, (PetscInt)max_iter_);

    // Shift-and-invert spectral transformation
    ST st;
    EPSGetST(eps, &st);
    STSetType(st, STSINVERT);

    // Direct solver for the shifted system
    KSP ksp;
    STGetKSP(st, &ksp);
    KSPSetType(ksp, KSPPREONLY);
    PC pc;
    KSPGetPC(ksp, &pc);
    PCSetType(pc, PCLU);
    // Let PETSc choose the best available parallel direct solver;
    // user can override at runtime with: -st_pc_factor_mat_solver_type mumps

    // Allow all runtime overrides via PETSc/SLEPc command-line options
    EPSSetFromOptions(eps);

    if (myid == 0 && verbose_ > 0) {
        std::cout << "  Solving with SLEPc (Krylov-Schur + shift-and-invert)..."
                  << std::endl;
    }

    // ── Solve ───────────────────────────────────────────────────────────────
    EPSSolve(eps);

    PetscInt nconv, niter;
    EPSGetConverged(eps, &nconv);
    EPSGetIterationNumber(eps, &niter);

    if (myid == 0 && verbose_ > 0) {
        std::cout << "  SLEPc converged: " << nconv << " eigenpair(s) in "
                  << niter << " iteration(s)." << std::endl;
    }

    // ── Extract eigenvalues and transverse eigenvectors ─────────────────────
    Vec xr, xi;
    MatCreateVecs(L, NULL, &xr);
    MatCreateVecs(L, NULL, &xi);

    // Set up VecScatter to extract the transverse (ND) part of the block vector.
    // In the block ordering, ND DOFs occupy global rows [0, nt_global).
    HYPRE_BigInt first_row_A = A.GetRowStarts()[0];
    std::vector<PetscInt> nd_indices(local_nt);
    for (int j = 0; j < local_nt; j++) {
        nd_indices[j] = (PetscInt)(first_row_A + j);
    }

    IS is_from;
    ISCreateGeneral(comm_, local_nt, nd_indices.data(),
                    PETSC_COPY_VALUES, &is_from);

    Vec xr_t;
    VecCreateMPI(comm_, local_nt, (PetscInt)nt_global, &xr_t);

    VecScatter scatter;
    VecScatterCreate(xr, is_from, xr_t, NULL, &scatter);

    // Clean up old results
    for (auto *v : eigenvectors_) delete v;
    eigenvalues_.clear();
    eigenvectors_.clear();

    int nextract = std::min((int)nconv, num_modes_);

    for (int i = 0; i < nextract; i++) {
        PetscScalar kr, ki;
        EPSGetEigenpair(eps, i, &kr, &ki, xr, xi);

        double eval = PetscRealPart(kr);
        eigenvalues_.push_back(eval);

        // Scatter transverse DOFs from block vector to ND-sized vector
        VecScatterBegin(scatter, xr, xr_t, INSERT_VALUES, SCATTER_FORWARD);
        VecScatterEnd(scatter, xr, xr_t, INSERT_VALUES, SCATTER_FORWARD);

        // Copy to HypreParVector
        HypreParVector *et = new HypreParVector(
            comm_, A.GetGlobalNumRows(), A.GetRowStarts());

        const PetscScalar *data;
        VecGetArrayRead(xr_t, &data);
        double *et_data = et->GetData();
        for (int j = 0; j < local_nt; j++) {
            et_data[j] = PetscRealPart(data[j]);
        }
        VecRestoreArrayRead(xr_t, &data);

        eigenvectors_.push_back(et);
    }

    if (myid == 0 && verbose_ > 0) {
        std::cout << "  Eigenvalues (beta^2):" << std::endl;
        for (int i = 0; i < nextract; i++) {
            double beta2 = eigenvalues_[i];
            double neff = beta2 > 0 ? std::sqrt(beta2) / std::sqrt(sigma_)
                          * std::sqrt(sigma_) / std::sqrt(sigma_ > 0 ? sigma_ : 1.0)
                          : 0.0;
            std::cout << "    " << i << ": beta^2 = " << std::setprecision(6)
                      << std::fixed << beta2 << std::endl;
        }
    }

    // ── Cleanup ─────────────────────────────────────────────────────────────
    VecScatterDestroy(&scatter);
    ISDestroy(&is_from);
    VecDestroy(&xr_t);
    VecDestroy(&xr);
    VecDestroy(&xi);
    EPSDestroy(&eps);
    MatDestroy(&L);
    MatDestroy(&R);
}

} // namespace eigensolve

#endif // EIGENSOLVE_USE_SLEPC
